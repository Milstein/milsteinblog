var ContactLocal = {
"Contact Us":"Get In Touch",
"All fields are mandatory.":"Todos os campos são de preenchimento obrigatório.",
"Name":"nome",
"Email":"Email",
"Message":"mensagem",
"Submit":"submeter",
"Your Email ID":"Seu e-mail ID"
}

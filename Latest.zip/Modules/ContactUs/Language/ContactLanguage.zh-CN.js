var ContactLocal = {
"Contact Us":"取得联系",
"All fields are mandatory.":"所有字段是强制性的。",
"Name":"名字",
"Email":"电子邮件",
"Message":"信息",
"Submit":"提交",
"Your Email ID":"您的电子邮件ID"
}

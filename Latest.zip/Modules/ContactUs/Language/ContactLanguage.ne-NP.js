var ContactLocal = {
"Contact Us":"संपर्कमा रहनुहोस्",
"All fields are mandatory.":"सबै फिल्डहरू अनिवार्य छन्!",
"Name":"नाम",
"Email":"ई-मेल",
"Message":"सन्देश",
"Submit":"सब्मित",
"Your Email ID":"तपाईंको इमेल आईडी"
}

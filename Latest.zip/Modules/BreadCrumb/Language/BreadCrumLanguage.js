﻿var BreadCrumLanguage = {
'Welcome': 'Welcome'
};
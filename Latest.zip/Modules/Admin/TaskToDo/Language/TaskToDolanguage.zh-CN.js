var TaskToDoLanguage = {
"All":"所有",
"Previous":"前",
"Today":"今天",
"UpComming":"即将到来",
"Add Task":"添加任务",
"Add New":"添加新",
"Update":"更新"
};

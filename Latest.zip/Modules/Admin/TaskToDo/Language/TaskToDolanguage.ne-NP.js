var TaskToDoLanguage = {
"All":"सबै",
"Previous":"पछिल्लो",
"Today":"आज",
"UpComing":"आउँदै गर्एको",
"Add Task":"कार्य थप गर्नुहोस्",
"Add New":"नयाँ थप्नुहोस्",
"Update":"अपडेट"
};

var TaskToDoLanguage = {
"All":"todos",
"Previous":"anterior",
"Today":"hoy",
"UpComing":"PRÓXIMOS",
"Add Task":"Agregar tarea?",
"Add New":"Agregar nuevo",
"Update":"actualización"
};

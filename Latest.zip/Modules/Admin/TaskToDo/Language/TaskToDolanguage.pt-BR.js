var TaskToDoLanguage = {
"All":"tudo",
"Previous":"anterior",
"Today":"hoje",
"UpComing":"Próximos",
"Add Task":"Adicionar tarefa?",
"Add New":"Adicionar Novo",
"Update":"atualizar"
};
